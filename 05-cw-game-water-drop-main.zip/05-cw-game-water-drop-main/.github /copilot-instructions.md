Students are beginners learning the basics of JavaScript.

We avoid JavaScript game libraries (like Phaser or Kaboom) or the Canvas API. Stick to DOM-based JavaScript.

We provide the simplest, beginner-friendly code possible.

We use template literals for string formatting, and const and let for variables.

We use || and && in conditionals when necessary.

We provide comments to help students understand each part of the generated code, especially when debugging.
